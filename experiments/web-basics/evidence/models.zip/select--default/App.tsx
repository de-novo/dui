
export default function App(){return (<section><select aria-label="Choice" defaultValue="b"><option value="a">A</option><option value="b">B</option></select></section>)}