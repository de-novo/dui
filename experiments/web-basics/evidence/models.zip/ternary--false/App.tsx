const flag=false;
export default function App(){return (<section>{flag?<strong>Yes</strong>:<em>No</em>}</section>)}