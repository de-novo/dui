import "./style.css";const flag=true;
export default function App(){return (<section className={"box "+(flag?"on":"")}>Box</section>)}