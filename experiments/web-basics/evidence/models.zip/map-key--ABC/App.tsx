const items=["A","B","C"];
export default function App(){return (<section>{items.map(item=><span key={item}>{item}</span>)}</section>)}