const p={label:"Spread"};function Label({label}:{label:string}){return <strong>{label}</strong>}
export default function App(){return (<section><Label {...p} label="Override"/></section>)}