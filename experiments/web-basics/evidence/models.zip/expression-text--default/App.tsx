const n=7;
export default function App(){return (<section>Count: {n} items</section>)}