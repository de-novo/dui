import "./style.css";
export default function App(){return (<section><strong/></section>)}