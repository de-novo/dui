
export default function App(){return (<section style={{padding:12,color:"#921c36"}}>Box</section>)}