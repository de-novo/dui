import "./style.css";
export default function App(){return (<section className="p-[12px] text-[#921c36]">Box</section>)}