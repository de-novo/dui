
export default function App(){return (<section style={{width:80,height:40,border:"3px solid #921c36"}}/>)}