
export default function App(){return (<section><><strong>A</strong><em>B</em></></section>)}