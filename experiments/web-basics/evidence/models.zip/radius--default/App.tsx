
export default function App(){return (<section style={{width:80,height:40,backgroundColor:"#16745c",borderRadius:12}}/>)}