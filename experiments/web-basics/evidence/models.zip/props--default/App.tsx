function Label({label}:{label:string}){return <strong>{label}</strong>}
export default function App(){return (<section><Label label="Ready"/></section>)}