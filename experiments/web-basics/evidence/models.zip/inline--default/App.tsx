
export default function App(){return (<section style={{width:70}}><span>one two </span><span>three four</span></section>)}