
export default function App(){return (<section style={{width:100,fontSize:16,lineHeight:"24px"}}>One small box with five words.</section>)}