
export default function App(){return (<section style={{width:50,height:20,overflow:"hidden"}}><div style={{width:90,height:40}}/></section>)}