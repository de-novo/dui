import {useState} from "react";
export default function App(){const [active]=useState(true);return (<section>{active?<strong>Open</strong>:<em>Closed</em>}</section>)}