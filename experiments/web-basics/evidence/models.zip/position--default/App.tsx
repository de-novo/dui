
export default function App(){return (<section style={{position:"relative",width:100,height:50}}><div style={{position:"absolute",left:14,top:8,width:20,height:10}}/></section>)}