
export default function App(){return (<section style={{width:40,height:20,backgroundColor:"#16745c",color:"#ffffff"}}>A</section>)}