
export default function App(){return (<section><input aria-label="Name" defaultValue="Ada"/></section>)}