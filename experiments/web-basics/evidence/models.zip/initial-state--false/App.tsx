import {useState} from "react";
export default function App(){const [active]=useState(false);return (<section>{active?<strong>Open</strong>:<em>Closed</em>}</section>)}