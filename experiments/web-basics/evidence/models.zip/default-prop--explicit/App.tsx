function Label({label="Default"}:{label?:string}){return <strong>{label}</strong>}
export default function App(){return (<section><Label label="Explicit"/></section>)}