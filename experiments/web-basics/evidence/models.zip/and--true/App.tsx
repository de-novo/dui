const flag=true;
export default function App(){return (<section>A{flag && <strong>B</strong>}</section>)}