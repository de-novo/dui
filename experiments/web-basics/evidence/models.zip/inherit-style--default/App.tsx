
export default function App(){return (<section style={{color:"#16745c",fontSize:18}}><span>Child</span></section>)}