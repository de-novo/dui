
export default function App(){return (<section style={{display:"grid",gridTemplateColumns:"40px 60px",gap:8}}><div>A</div><div>B</div></section>)}