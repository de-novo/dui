const items=[];
export default function App(){return (<section>{items.map(item=><span key={item}>{item}</span>)}</section>)}