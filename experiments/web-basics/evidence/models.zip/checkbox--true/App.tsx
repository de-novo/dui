
export default function App(){return (<section><input aria-label="Done" type="checkbox" defaultChecked={true}/></section>)}