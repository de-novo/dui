
export default function App(){return (<section style={{width:80,height:24,transform:"translateX(18px) rotate(20deg) scale(1.2)"}}/>)}