
export default function App(){return (<section><div style={{width:80,height:20}}/><div style={{width:45,height:10}}/></section>)}