import a from "./a.module.css";
import b from "./b.module.css";
export default function App(){return (<section><strong className={a.tile}>A</strong><em className={b.tile}>B</em></section>)}