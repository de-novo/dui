import "./style.css";const flag=false;
export default function App(){return (<section className={"box "+(flag?"on":"")}>Box</section>)}