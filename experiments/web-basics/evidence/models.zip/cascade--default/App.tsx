import "./style.css";
export default function App(){return (<section className="box" id="target">Box</section>)}