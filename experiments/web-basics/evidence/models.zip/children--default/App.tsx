function Frame({children}:{children:any}){return <article>{children}</article>}
export default function App(){return (<section><Frame><strong>A</strong><em>B</em></Frame></section>)}