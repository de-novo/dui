
export default function App(){return (<section style={{width:80,height:24,transform:"translate(12px,6px)"}}/>)}