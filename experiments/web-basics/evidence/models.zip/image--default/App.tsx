
export default function App(){return (<section><img src="./mark.png" alt="Green square" width={32} height={24}/></section>)}