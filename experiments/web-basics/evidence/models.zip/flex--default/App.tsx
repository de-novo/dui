
export default function App(){return (<section style={{display:"flex",gap:12,alignItems:"center"}}><div style={{width:20,height:28}}/><div style={{width:30,height:10}}/></section>)}