const items=["C","A","B"];
export default function App(){return (<section>{items.map(item=><span key={item}>{item}</span>)}</section>)}