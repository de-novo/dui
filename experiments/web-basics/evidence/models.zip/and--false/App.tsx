const flag=false;
export default function App(){return (<section>A{flag && <strong>B</strong>}</section>)}