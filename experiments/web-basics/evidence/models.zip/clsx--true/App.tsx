import "./style.css";import clsx from "clsx";const flag=true;
export default function App(){return (<section className={clsx("box",flag && "on")}>Box</section>)}